package com.capgemini.bank.bean;

import java.sql.Date;
import java.time.LocalDate;

public class DemandDraft {
private int transactionId;
private String customerName,inFavorOf;
private long phoneNumber;
private LocalDate dateOfTransaction;
private int ddAmount,ddCommission;
private String ddDescription;
public DemandDraft() {
	super();
}
public DemandDraft(int transactionId, String customerName, String inFavorOf,
		long phoneNumber,LocalDate dateOfTransaction, int ddAmount,
		int ddCommission, String ddDescription) {
	super();
	this.transactionId = transactionId;
	this.customerName = customerName;
	this.inFavorOf = inFavorOf;
	this.phoneNumber = phoneNumber;
	this.dateOfTransaction = dateOfTransaction;
	this.ddAmount = ddAmount;
	this.ddCommission = ddCommission;
	this.ddDescription = ddDescription;
}
public int getTransactionId() {
	return transactionId;
}
public void setTransactionId(int transactionId) {
	this.transactionId = transactionId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getInFavorOf() {
	return inFavorOf;
}
public void setInFavorOf(String inFavorOf) {
	this.inFavorOf = inFavorOf;
}
public long getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(long phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public LocalDate getDateOfTransaction() {
	return dateOfTransaction;
}
public DemandDraft(String customerName, long phoneNumber, String inFavorOf,
		int ddAmount, String ddDescription) {
	super();
	this.customerName = customerName;
	this.inFavorOf = inFavorOf;
	this.phoneNumber = phoneNumber;
	this.ddAmount = ddAmount;
	this.ddDescription = ddDescription;
}
public DemandDraft(String customerName, String inFavorOf, long phoneNumber,
		LocalDate dateOfTransaction, int ddAmount, int ddCommission,
		String ddDescription) {
	super();
	this.customerName = customerName;
	this.inFavorOf = inFavorOf;
	this.phoneNumber = phoneNumber;
	this.dateOfTransaction = dateOfTransaction;
	this.ddAmount = ddAmount;
	this.ddCommission = ddCommission;
	this.ddDescription = ddDescription;
}
public void setDateOfTransaction(LocalDate dateOfTransaction) {
	this.dateOfTransaction = dateOfTransaction;
}
public int getDdAmount() {
	return ddAmount;
}
public void setDdAmount(int ddAmount) {
	this.ddAmount = ddAmount;
}
public int getDdCommission() {
	return ddCommission;
}
public void setDdCommission(int ddCommission) {
	this.ddCommission = ddCommission;
}
public String getDdDescription() {
	return ddDescription;
}
public void setDdDescription(String ddDescription) {
	this.ddDescription = ddDescription;
}


}
