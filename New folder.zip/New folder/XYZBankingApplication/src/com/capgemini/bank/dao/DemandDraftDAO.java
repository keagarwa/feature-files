package com.capgemini.bank.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.util.ConnectionProvider;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
public class DemandDraftDAO implements IDemandDraftDAO {
	private Connection conn=ConnectionProvider.getDBConnection();
	private static final Logger logger=Logger.getLogger(DemandDraftService.class);
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException {
try{
			conn.setAutoCommit(false);
			PreparedStatement pstmt1 = conn.prepareStatement("INSERT INTO demand_draft(customer_name,in_favor_of,phone_number,date_of_transaction,dd_amount,dd_commission,dd_description) values (?,?,?,?,?,?,?)");
			pstmt1.setString(1, demandDraft.getCustomerName());
			pstmt1.setString(2, demandDraft.getInFavorOf());
			pstmt1.setLong(3, demandDraft.getPhoneNumber());
			pstmt1.setString(4,"2018-12-10");
			pstmt1.setInt(5, demandDraft.getDdAmount());
			pstmt1.setInt(6,demandDraft.getDdCommission());
			pstmt1.setString(7, demandDraft.getDdDescription());
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt2 = conn.prepareStatement("select max(associateId) from Associate");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int transactionId = rs.getInt(1);
			
			conn.commit();
			demandDraft.setTransactionId(transactionId);
		
			return transactionId;
		
		}catch (SQLException e){
			conn.rollback();
			conn.close();
			e.printStackTrace();
		}
		finally{
			conn.setAutoCommit(true);
		}
return 0;
	}
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		PreparedStatement pstmt1 = conn.prepareStatement("Select * from demand_draft where transactionId="+transactionId);
		ResultSet bankingRS = pstmt1.executeQuery();
		if(bankingRS.next()) {
			
			String customer_name=bankingRS.getString("customer_name");
			String firstName=bankingRS.getString("in_favor_of");
			Long phoneNumber=bankingRS.getLong("phone_number");
			LocalDate dateOfTrnsaction=bankingRS.getString("date_of_rnsaction");
			int ddAmount=bankingRS.getInt("dd_amount");
			int ddDescription=bankingRS.getInt("dd_commission");
		
			
			DemandDraft demandDraft = new DemandDraft(customerName,inFavorOf, phoneNumber, dateOfTransaction, ddAmount, ddCommission, ddDescription);
			
			PreparedStatement pstmt2 = conn.prepareStatement("Select * from BankDetails where associateId="+associateId);
			ResultSet bankdetailsRs=pstmt2.executeQuery();
			bankdetailsRs.next();
			
			int accountNumber=bankdetailsRs.getInt("accountNumber");
			String bankName=bankdetailsRs.getString("bankName");
			String ifscCode=bankdetailsRs.getString("ifscCode");
			demandDraft.setBankDetails(new BankDetails(accountNumber, bankName, ifscCode));
			
			return demandDraft;
	}
	

}
