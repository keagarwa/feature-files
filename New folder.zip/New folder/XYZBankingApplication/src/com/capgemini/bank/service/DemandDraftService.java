package com.capgemini.bank.service;
import java.sql.SQLException;
import java.time.LocalDate;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exceptions.DdAmountNotValidExceptions;
public class DemandDraftService implements IDemandDraftService {

	IDemandDraftDAO demandDraftDao=new DemandDraftDAO();
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws DdAmountNotValidExceptions, SQLException {
		String name=demandDraft.getCustomerName();
		long phoneNumber=demandDraft.getPhoneNumber();
		String inFavorOf=demandDraft.getInFavorOf();
		int ddAmount=demandDraft.getDdAmount();
		String ddDescription=demandDraft.getDdDescription();
		
		int commission;
		if(ddAmount<=5000)
			commission=10;
		else if(ddAmount<=10000)
			commission=41;
		else if(ddAmount<=100000)
			commission=51;
		else if(ddAmount<=500000)
			commission=306;
		else
				throw new DdAmountNotValidExceptions();
				
				LocalDate todayDate=LocalDate.now();
				DemandDraft demandDraft2=new DemandDraft();
				demandDraft2.setCustomerName(name);
				demandDraft2.setDateOfTransaction(todayDate);
				demandDraft2.setDdAmount(ddAmount);
				demandDraft2.setDdCommission(commission);
				demandDraft2.setDdDescription(ddDescription);
				demandDraft2.setInFavorOf(inFavorOf);
				

				
					int transactionId = demandDraftDao.addDemandDraftDetails(demandDraft2);
					return transactionId;
				
	}
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {

		return null;
	}

}
