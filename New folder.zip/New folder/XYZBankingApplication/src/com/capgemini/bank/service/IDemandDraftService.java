package com.capgemini.bank.service;
import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.DdAmountNotValidExceptions;
public interface IDemandDraftService {
int addDemandDraftDetails(DemandDraft demandDraft) throws DdAmountNotValidExceptions, SQLException;
DemandDraft getDemandDraftDetails(int transactionId);
}
