package com.capgemini.bank.ui;

import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
import com.capgemini.bank.util.ConnectionProvider;

public class Client {
	public static void main(String[] args) {
		if(ConnectionProvider.getDBConnection()!=null)
			System.out.println("Connection has established");
		else
			System.out.println("Connection has not been setup");
	}
	IDemandDraftService idemandDraftService=new DemandDraftService();
	DemandDraft demandDraft=new DemandDraft("John",97685873,"Capgemini",45000,"DD taken in favor of Capgemini");
	int transactionId=idemandDraftService.addDemandDraftDetails(demandDraft);
	
	System.out.println(transactionId);


	Scanner  sc=new Scanner(System.in);
	do{
		System.out.println("1.Enter Demand Draft Details");
		System.out.println("2.Exit");
		System.out.println("Enter your Choice");
		int choice=sc.nextInt();
		switch(choice){
		case 1:
		System.out.println("Enter the name of the customer");
		demandDraft.setCustomerName(sc.next());
		System.out.println("Enter customer phone number");
		demandDraft.setPhoneNumber(sc.nextLong());
		System.out.println("In favor of");
		demandDraft.setInFavorOf(sc.next());
		System.out.println("Enter Demand Draft amount(in Rs.)");
		demandDraft.setDdAmount(sc.nextInt());
		System.out.println("Enter Remarks");
		demandDraft.setDdDescription(sc.next());
		System.out.println("Your Demand Draft request has been successfully registered along with the "+transactionId);
		break;
		default:
			System.out.println("Invalid data Entered");
			System.out.println("Do you want to continue(Y/N)");
			String s=sc.next();
		}
	}while(s.startsWith("Y")||s.startsWith("y"));

}
}
